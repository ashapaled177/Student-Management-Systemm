#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DATA_FILE "students.dat"
#define TEMP_FILE "students.tmp"
#define MAX_NAME 60
#define MAX_COURSE 40

typedef struct {
    int roll;
    char name[MAX_NAME];
    char course[MAX_COURSE];
    float marks;
} Student;

void clearInput(void) {
    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF) {}
}

void readLine(const char *prompt, char *buffer, size_t size) {
    printf("%s", prompt);
    if (fgets(buffer, (int)size, stdin) != NULL) {
        buffer[strcspn(buffer, "\n")] = '\0';
    } else {
        buffer[0] = '\0';
    }
}

int readInt(const char *prompt) {
    int value;
    while (1) {
        printf("%s", prompt);
        if (scanf("%d", &value) == 1) {
            clearInput();
            return value;
        }
        printf("Please enter a valid whole number.\n");
        clearInput();
    }
}

float readMarks(void) {
    float marks;
    while (1) {
        printf("Enter marks (0-100): ");
        if (scanf("%f", &marks) == 1) {
            clearInput();
            if (marks >= 0 && marks <= 100) return marks;
        } else {
            clearInput();
        }
        printf("Invalid marks. Enter a value between 0 and 100.\n");
    }
}

int rollExists(int roll) {
    FILE *fp = fopen(DATA_FILE, "rb");
    Student s;
    if (!fp) return 0;

    while (fread(&s, sizeof(Student), 1, fp) == 1) {
        if (s.roll == roll) {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

void addStudent(void) {
    Student s;
    FILE *fp;

    printf("\n--- Add Student ---\n");
    s.roll = readInt("Enter roll number: ");

    if (s.roll <= 0) {
        printf("Roll number must be positive.\n");
        return;
    }
    if (rollExists(s.roll)) {
        printf("A student with this roll number already exists.\n");
        return;
    }

    readLine("Enter student name: ", s.name, sizeof(s.name));
    readLine("Enter course/class: ", s.course, sizeof(s.course));

    if (strlen(s.name) == 0 || strlen(s.course) == 0) {
        printf("Name and course cannot be empty.\n");
        return;
    }

    s.marks = readMarks();

    fp = fopen(DATA_FILE, "ab");
    if (!fp) {
        perror("Unable to open data file");
        return;
    }

    if (fwrite(&s, sizeof(Student), 1, fp) == 1)
        printf("Student added successfully.\n");
    else
        printf("Could not save student record.\n");

    fclose(fp);
}

void displayStudents(void) {
    FILE *fp = fopen(DATA_FILE, "rb");
    Student s;
    int count = 0;

    printf("\n--- All Students ---\n");
    if (!fp) {
        printf("No student records found yet.\n");
        return;
    }

    printf("%-8s %-25s %-20s %-8s %-10s\n",
           "Roll", "Name", "Course", "Marks", "Result");
    printf("--------------------------------------------------------------------------\n");

    while (fread(&s, sizeof(Student), 1, fp) == 1) {
        printf("%-8d %-25.25s %-20.20s %-8.2f %-10s\n",
               s.roll, s.name, s.course, s.marks,
               s.marks >= 35 ? "Pass" : "Fail");
        count++;
    }

    if (count == 0) printf("No student records found.\n");
    else printf("\nTotal students: %d\n", count);

    fclose(fp);
}

void searchStudent(void) {
    int roll, found = 0;
    Student s;
    FILE *fp = fopen(DATA_FILE, "rb");

    printf("\n--- Search Student ---\n");
    roll = readInt("Enter roll number: ");

    if (!fp) {
        printf("No student records found.\n");
        return;
    }

    while (fread(&s, sizeof(Student), 1, fp) == 1) {
        if (s.roll == roll) {
            printf("\nStudent found:\n");
            printf("Roll number : %d\n", s.roll);
            printf("Name        : %s\n", s.name);
            printf("Course      : %s\n", s.course);
            printf("Marks       : %.2f/100\n", s.marks);
            printf("Result      : %s\n", s.marks >= 35 ? "Pass" : "Fail");
            found = 1;
            break;
        }
    }

    if (!found) printf("Student with roll number %d was not found.\n", roll);
    fclose(fp);
}

void updateStudent(void) {
    int roll, found = 0;
    Student s;
    FILE *fp = fopen(DATA_FILE, "rb+");

    printf("\n--- Update Student ---\n");
    roll = readInt("Enter roll number to update: ");

    if (!fp) {
        printf("No student records found.\n");
        return;
    }

    while (fread(&s, sizeof(Student), 1, fp) == 1) {
        if (s.roll == roll) {
            printf("Current name: %s\n", s.name);
            readLine("Enter new name: ", s.name, sizeof(s.name));
            readLine("Enter new course/class: ", s.course, sizeof(s.course));
            s.marks = readMarks();

            fseek(fp, -(long)sizeof(Student), SEEK_CUR);
            if (fwrite(&s, sizeof(Student), 1, fp) == 1)
                printf("Student record updated successfully.\n");
            else
                printf("Could not update student record.\n");

            found = 1;
            break;
        }
    }

    if (!found) printf("Student with roll number %d was not found.\n", roll);
    fclose(fp);
}

void deleteStudent(void) {
    int roll, found = 0;
    Student s;
    FILE *fp = fopen(DATA_FILE, "rb");
    FILE *temp;

    printf("\n--- Delete Student ---\n");
    roll = readInt("Enter roll number to delete: ");

    if (!fp) {
        printf("No student records found.\n");
        return;
    }

    temp = fopen(TEMP_FILE, "wb");
    if (!temp) {
        printf("Unable to create temporary file.\n");
        fclose(fp);
        return;
    }

    while (fread(&s, sizeof(Student), 1, fp) == 1) {
        if (s.roll == roll) {
            found = 1;
        } else {
            fwrite(&s, sizeof(Student), 1, temp);
        }
    }

    fclose(fp);
    fclose(temp);

    if (remove(DATA_FILE) != 0) {
        printf("Could not replace the original data file.\n");
        remove(TEMP_FILE);
        return;
    }

    if (rename(TEMP_FILE, DATA_FILE) != 0) {
        printf("Could not finish deleting the record.\n");
        return;
    }

    if (found) printf("Student record deleted successfully.\n");
    else printf("Student with roll number %d was not found.\n", roll);
}

void showMenu(void) {
    printf("\n====================================\n");
    printf("       STUDENT MANAGEMENT SYSTEM\n");
    printf("====================================\n");
    printf("1. Add student\n");
    printf("2. Display all students\n");
    printf("3. Search student\n");
    printf("4. Update student\n");
    printf("5. Delete student\n");
    printf("6. Exit\n");
    printf("------------------------------------\n");
}

int main(void) {
    int choice;

    while (1) {
        showMenu();
        choice = readInt("Enter your choice (1-6): ");

        switch (choice) {
            case 1: addStudent(); break;
            case 2: displayStudents(); break;
            case 3: searchStudent(); break;
            case 4: updateStudent(); break;
            case 5: deleteStudent(); break;
            case 6:
                printf("Thank you for using Student Management System!\n");
                return 0;
            default:
                printf("Invalid choice. Please select 1 to 6.\n");
        }
    }
}
