# Student Management System (C)

A menu-driven BCA mini-project written in C. It stores student records in a local binary file, so records remain available after closing the program.

## Features
1. Add a student (roll number, name, course/class, marks)
2. Display all student records
3. Search by roll number
4. Update a student record
5. Delete a student record
6. Automatically show Pass/Fail (35 marks is the pass mark used in this sample)

## Requirements
- GCC compiler (MinGW-w64 on Windows, or GCC on Linux/macOS)
- VS Code is optional; any C compiler/IDE can run the project

## Run in VS Code on Windows
1. Install a GCC compiler such as MinGW-w64 and make sure `gcc` is added to PATH.
2. Open this project folder in VS Code.
3. Open Terminal > New Terminal.
4. Compile:
   ```bash
   gcc main.c -o student_management.exe
   ```
5. Run:
   ```bash
   .\student_management.exe
   ```

If using PowerShell and the command does not run, use:
```powershell
.\student_management.exe
```

## Run on Linux/macOS
```bash
gcc main.c -o student_management
./student_management
```

## Data file
The program creates `students.dat` in the current working directory the first time a record is added. Keep this file to preserve records. Deleting it resets the project data.

## Example workflow
- Choose `1` to add a student.
- Choose `2` to see all students.
- Choose `3` and enter a roll number to search.
- Choose `4` to edit a record.
- Choose `5` to delete a record.
- Choose `6` to exit.

## Concepts demonstrated
Structures, arrays of characters, functions, loops, switch statements, input validation, file handling (`fread`, `fwrite`, `fseek`, `remove`, `rename`).

## Notes
This is an educational console project, not a production student database. Make a backup of `students.dat` before experimenting with file operations.
